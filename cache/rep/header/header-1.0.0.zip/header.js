/*!
 * header
 * https://github.com/gavinning/jasmine
 *
 * Template
 * Date: 2015-06-15
 */

var app, App;

App = require('app');
app = App.create({
	name: 'header',
	version: '1.0.0',
	template: require('./header.jade'),
});

module.exports = app;
