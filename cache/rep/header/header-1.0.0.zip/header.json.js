/*!
 * Mock data for mock.js
 * http://ilinco.com/
 *
 * Template
 * Date: 2015-06-15
 */


module.exports = {
	title: '掌上NBA',
	leftClassName: 'iback',
	rightClassName: 'icenter'
}