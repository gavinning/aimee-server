/*!
 * Mock data for mock.js
 * http://ilinco.com/
 *
 * Template
 * Date: 2015-06-15
 */


module.exports = {

}