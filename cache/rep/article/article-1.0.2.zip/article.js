/*!
 * article
 * https://github.com/gavinning/aimee
 *
 * Template
 * Date: 2015-06-15
 */

var app, App;

App = require('app');
app = App.create({
	name: 'article',
	version: '1.0.0',
	template: require('./article.jade'),
	postrender: function(thisApp){
		var Share = require('share');
		var share = new Share;
		share.init();
		this.find('#share').replaceWith(share.getApp());

		var shareMore = this.find('.lk-share.more');

		shareMore.click(function(){
			var shareMask = pm.map.home.app.sharely[0].getApp().find('.share-mask');

			shareMask.css('top', window.scrollY).addClass("share-mask-show");

			shareMask.click(function(e){
				e.stopPropagation();
				$(this).addClass("share-mask-hide").removeClass("share-mask-show");
			});
			shareMask[0].addEventListener('webkitAnimationEnd', function(){
				$(this).removeClass("share-mask-hide");
			}, false);

		});

	}	
});

module.exports = app;